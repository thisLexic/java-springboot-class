package app.components;

import org.springframework.stereotype.Component;

@Component
public class DividerComponent {

	public double divide(double a, double b)
	{
		return a/b;
	}
}
