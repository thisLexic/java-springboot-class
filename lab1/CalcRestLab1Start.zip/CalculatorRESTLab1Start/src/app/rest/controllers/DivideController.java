package app.rest.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import app.components.DividerComponent;

@Component
@Path("/tester")
public class DivideController {
	
	
	Logger logger = LoggerFactory.getLogger(DivideController.class);

	
	@Autowired
	DividerComponent divider;
	
	@GET
	@Path("/divide")
	@Produces(MediaType.TEXT_PLAIN)
	public double divide(@QueryParam("a") double a, @QueryParam("b") double b)
	{
		return divider.divide(a, b);
	}
}
